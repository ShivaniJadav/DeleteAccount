var express = require("express");
var router = express.Router();
var usersController = require("../controllers/users_controller");
const otpGenerator = require('otp-generator')
require('dotenv').config();

router.get("/", async function (req, res, next) {
  if(req.session.email) {
    res.render("otp-verification", {email: req.session.email });
  } else {
    // res.render('delete-account', {error: ''});
    res.redirect('/')
  }
});

router.get("/verify", async function (req, res, next) {
    res.render('delete-account');
});

router.post("/", async function (req, res, next) {
  try {
    if (typeof req.body.email == "undefined" || req.body.email == "") {
      res.render("delete-account", {email: req.body.email, error: "Please enter email!" });
      // res.render("error", { error: "Please enter email!" });
    } else {
      if(typeof req.body.reason != "undefined" && req.body.reason != '') {
        req.session.reason = req.body.reason;
      }
        let isEmailExists = await usersController.isEmailExists(req.body.email);
        if (isEmailExists) {
          req.session.email = req.body.email;
          let otp = await otpGenerator.generate(6, { upperCaseAlphabets: false, specialChars: false, digits: true, lowerCaseAlphabets: false });
          let result = usersController.sendotp(req.body.email, otp);
          // if (result.status) {
            res.render("otp-verification", {email: req.body.email });
          // } else {
          //   res.render("error", { error: result.data });
          // }
        } else {
          res.render("delete-account", {email: req.body.email, error: "This email is not registered!" });
          // res.render("error", { error: "This email is not registered!" });
        }
    }
  } catch (error) {
    res.render("error", { error: error });
  }
});

router.post("/verify", async function (req, res, next) {
  try {
    if (typeof req.body.otp == "undefined" || req.body.otp == "") {
      res.render("error", { error: "Please enter OTP!" });
    } else {
      let isEmailExists = await usersController.isEmailExists(req.body.email);
        if (isEmailExists) {
      if(await usersController.verifyotp(req.body.email, req.body.otp)) {
        if(await usersController.deleteAccount(req.body.email)) {
          let html = `<p>The Account with Email ${req.body.email} has been deleted.</p>`;
          if(typeof req.session.reason != "undefined" && req.session.reason != '') {
            html += `<p><b>Reason for leaving: </b> ${req.session.reason} </p>`
          }
          usersController.sendMail(process.env.ADMIN_EMAIL, {
            html: html,
            subject: "FirmPet: Account Deleted"
          });
          req.session.email = '';
          res.render('delete-confirm')  
        } else {
          res.render("error", { error: "Account still active. Please try again!" });  
        }
      } else {
        res.render("error", { error: "Invalid OTP!" });
      }
    } else {
      res.render("error", { error: "Account is already deactivated!" });
    }
    }
  } catch (error) {
    res.render("error", { error: error });
  }
});

module.exports = router;
